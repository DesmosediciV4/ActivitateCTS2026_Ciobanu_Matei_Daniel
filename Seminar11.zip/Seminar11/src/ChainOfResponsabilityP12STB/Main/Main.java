package ChainOfResponsabilityP12STB.Main;

import ChainOfResponsabilityP12STB.Clase.*;

public class Main {
    public static void main(String[] args) {
        CalatorieHandler calatorieTroleibuz = new CalatorieTroileibuz();
        CalatorieHandler calatorieAutobuz = new CalatorieAutobuz();
        CalatorieHandler calatorieTramvai = new CalatorieTramvai();
        CalatorieHandler calatorieMetrou = new CalatorieMetrou();

        calatorieTroleibuz.setSuccesorCalatorie(calatorieAutobuz);
        calatorieAutobuz.setSuccesorCalatorie(calatorieTramvai);
        calatorieTramvai.setSuccesorCalatorie(calatorieMetrou);

        System.out.println(calatorieTroleibuz.recomandariCalatorie(5));
        System.out.println(calatorieAutobuz.recomandariCalatorie(12));
        System.out.println(calatorieTramvai.recomandariCalatorie(2));
        System.out.println(calatorieMetrou.recomandariCalatorie(4));
    }
}